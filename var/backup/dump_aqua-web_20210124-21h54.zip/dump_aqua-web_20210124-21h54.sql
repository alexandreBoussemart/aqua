--
-- Backup aqua-web - 2021-01-24 21:54:54
--


SET FOREIGN_KEY_CHECKS=0;


CREATE DATABASE IF NOT EXISTS `aqua-web`;
USE `aqua-web`;


--
-- Table core_config
--

DROP TABLE IF EXISTS `core_config`;

CREATE TABLE IF NOT EXISTS `core_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `groupe` int(11) NOT NULL,
  `label` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `core_config` VALUES("1", "config_temperature_declenchement", "29", "string", "1", "Température déclenchement ventilateur");
INSERT INTO `core_config` VALUES("5", "check_changement_eau", "15", "string", "2", "Nombre de jours avant alert changement d\'eau");
INSERT INTO `core_config` VALUES("6", "check_clean_reacteur", "15", "string", "2", "Nombre de jours avant alert nettoyage réacteur");
INSERT INTO `core_config` VALUES("7", "check_clean_ecumeur", "30", "string", "2", "Nombre de jours avant alert nettoyage écumeur");
INSERT INTO `core_config` VALUES("8", "check_clean_pompes", "90", "string", "2", "Nombre de jours avant alert nettoyage pompes");
INSERT INTO `core_config` VALUES("9", "check_analyse_eau", "6", "string", "2", "Nombre de jours avant alert analyse d\'eau");
INSERT INTO `core_config` VALUES("10", "temperature_max", "28", "string", "3", "Température autorisée minimum");
INSERT INTO `core_config` VALUES("11", "temperature_min", "23", "string", "3", "Température autorisée maximum");


-- --------------------------------------------------------


--
-- Table data_changement_eau
--

DROP TABLE IF EXISTS `data_changement_eau`;

CREATE TABLE IF NOT EXISTS `data_changement_eau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `data_changement_eau` VALUES("1", "2019-12-17 23:25:36", "20");
INSERT INTO `data_changement_eau` VALUES("2", "2019-12-23 18:26:38", "20");
INSERT INTO `data_changement_eau` VALUES("3", "2019-12-25 22:50:56", "20");
INSERT INTO `data_changement_eau` VALUES("4", "2019-12-28 15:13:07", "20");
INSERT INTO `data_changement_eau` VALUES("5", "2019-12-30 09:13:45", "20");
INSERT INTO `data_changement_eau` VALUES("6", "2020-01-06 20:54:00", "20");
INSERT INTO `data_changement_eau` VALUES("7", "2020-01-14 22:02:23", "20");
INSERT INTO `data_changement_eau` VALUES("8", "2020-01-21 20:23:41", "20");
INSERT INTO `data_changement_eau` VALUES("9", "2020-01-28 21:11:04", "20");
INSERT INTO `data_changement_eau` VALUES("10", "2020-01-30 09:15:45", "20");
INSERT INTO `data_changement_eau` VALUES("11", "2020-01-30 18:15:45", "10");
INSERT INTO `data_changement_eau` VALUES("12", "2020-02-06 12:28:51", "20");
INSERT INTO `data_changement_eau` VALUES("14", "2020-02-22 10:55:27", "20");
INSERT INTO `data_changement_eau` VALUES("15", "2020-03-04 22:08:39", "20");
INSERT INTO `data_changement_eau` VALUES("16", "2020-05-07 18:58:17", "20");


-- --------------------------------------------------------


--
-- Table data_clean_ecumeur
--

DROP TABLE IF EXISTS `data_clean_ecumeur`;

CREATE TABLE IF NOT EXISTS `data_clean_ecumeur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `data_clean_ecumeur` VALUES("1", "2020-01-30 13:44:17");
INSERT INTO `data_clean_ecumeur` VALUES("2", "2020-05-07 18:59:47");


-- --------------------------------------------------------


--
-- Table data_clean_pompes
--

DROP TABLE IF EXISTS `data_clean_pompes`;

CREATE TABLE IF NOT EXISTS `data_clean_pompes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `data_clean_pompes` VALUES("1", "2019-12-03 19:49:20");
INSERT INTO `data_clean_pompes` VALUES("2", "2020-05-07 18:59:44");


-- --------------------------------------------------------


--
-- Table data_clean_reacteur
--

DROP TABLE IF EXISTS `data_clean_reacteur`;

CREATE TABLE IF NOT EXISTS `data_clean_reacteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `data_clean_reacteur` VALUES("1", "2020-02-13 19:11:34");
INSERT INTO `data_clean_reacteur` VALUES("2", "2020-02-23 14:11:47");
INSERT INTO `data_clean_reacteur` VALUES("3", "2020-03-05 13:02:57");
INSERT INTO `data_clean_reacteur` VALUES("4", "2020-05-07 18:59:49");
INSERT INTO `data_clean_reacteur` VALUES("5", "2020-10-09 19:15:49");
INSERT INTO `data_clean_reacteur` VALUES("6", "2020-10-09 19:16:08");


-- --------------------------------------------------------


--
-- Table data_osmolateur
--

DROP TABLE IF EXISTS `data_osmolateur`;

CREATE TABLE IF NOT EXISTS `data_osmolateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- --------------------------------------------------------


--
-- Table data_parametres_eau
--

DROP TABLE IF EXISTS `data_parametres_eau`;

CREATE TABLE IF NOT EXISTS `data_parametres_eau` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` varchar(10) CHARACTER SET utf8 NOT NULL,
  `value` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;

INSERT INTO `data_parametres_eau` VALUES("1", "2020-01-30 00:00:00", "kh", "7.7");
INSERT INTO `data_parametres_eau` VALUES("2", "2020-02-02 00:00:00", "kh", "7.3");
INSERT INTO `data_parametres_eau` VALUES("3", "2020-01-30 00:00:00", "ca", "425");
INSERT INTO `data_parametres_eau` VALUES("4", "2020-02-02 00:00:00", "ca", "420");
INSERT INTO `data_parametres_eau` VALUES("5", "2020-01-30 00:00:00", "mg", "1455");
INSERT INTO `data_parametres_eau` VALUES("6", "2020-02-02 00:00:00", "mg", "1455");
INSERT INTO `data_parametres_eau` VALUES("7", "2020-01-30 00:00:00", "densite", "1023");
INSERT INTO `data_parametres_eau` VALUES("8", "2020-02-02 00:00:00", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("9", "2020-02-03 19:20:43", "kh", "6.7");
INSERT INTO `data_parametres_eau` VALUES("10", "2020-02-03 19:24:08", "ca", "420");
INSERT INTO `data_parametres_eau` VALUES("11", "2020-02-03 19:27:09", "mg", "1485");
INSERT INTO `data_parametres_eau` VALUES("12", "2020-02-03 19:30:13", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("13", "2020-02-04 20:01:14", "kh", "6.4");
INSERT INTO `data_parametres_eau` VALUES("14", "2020-02-04 20:05:01", "mg", "1500");
INSERT INTO `data_parametres_eau` VALUES("15", "2020-02-04 20:07:49", "ca", "435");
INSERT INTO `data_parametres_eau` VALUES("16", "2020-02-04 23:42:25", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("17", "2020-02-05 19:56:57", "mg", "1485");
INSERT INTO `data_parametres_eau` VALUES("18", "2020-02-05 20:00:30", "ca", "435");
INSERT INTO `data_parametres_eau` VALUES("19", "2020-02-05 20:03:40", "kh", "7.7");
INSERT INTO `data_parametres_eau` VALUES("20", "2020-02-05 20:31:56", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("21", "2020-02-06 19:41:46", "kh", "8.1");
INSERT INTO `data_parametres_eau` VALUES("22", "2020-02-06 19:41:47", "ca", "440");
INSERT INTO `data_parametres_eau` VALUES("23", "2020-02-06 19:41:47", "mg", "1485");
INSERT INTO `data_parametres_eau` VALUES("24", "2020-02-06 19:41:47", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("25", "2020-02-09 13:19:14", "kh", "7.7");
INSERT INTO `data_parametres_eau` VALUES("26", "2020-02-09 13:19:14", "ca", "425");
INSERT INTO `data_parametres_eau` VALUES("27", "2020-02-09 13:19:14", "mg", "1470");
INSERT INTO `data_parametres_eau` VALUES("28", "2020-02-09 13:19:14", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("29", "2020-02-10 19:16:28", "ca", "430");
INSERT INTO `data_parametres_eau` VALUES("30", "2020-02-10 19:16:28", "mg", "1425");
INSERT INTO `data_parametres_eau` VALUES("31", "2020-02-10 19:16:28", "kh", "7.7");
INSERT INTO `data_parametres_eau` VALUES("32", "2020-02-10 19:16:28", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("33", "2020-02-13 16:05:02", "kh", "7.7");
INSERT INTO `data_parametres_eau` VALUES("34", "2020-02-13 16:05:02", "ca", "445");
INSERT INTO `data_parametres_eau` VALUES("35", "2020-02-13 16:05:02", "mg", "1440");
INSERT INTO `data_parametres_eau` VALUES("36", "2020-02-13 16:05:02", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("37", "2020-02-15 17:28:22", "ca", "425");
INSERT INTO `data_parametres_eau` VALUES("38", "2020-02-15 17:31:20", "kh", "8.9");
INSERT INTO `data_parametres_eau` VALUES("39", "2020-02-15 17:34:47", "mg", "1410");
INSERT INTO `data_parametres_eau` VALUES("40", "2020-02-15 17:34:47", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("41", "2020-02-22 12:48:31", "mg", "1425");
INSERT INTO `data_parametres_eau` VALUES("42", "2020-02-22 12:51:17", "ca", "450");
INSERT INTO `data_parametres_eau` VALUES("43", "2020-02-22 12:51:17", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("44", "2020-02-22 12:53:23", "kh", "7.3");
INSERT INTO `data_parametres_eau` VALUES("45", "2020-02-27 12:27:45", "ca", "460");
INSERT INTO `data_parametres_eau` VALUES("46", "2020-02-27 12:31:05", "kh", "7");
INSERT INTO `data_parametres_eau` VALUES("47", "2020-03-05 11:11:10", "mg", "1490");
INSERT INTO `data_parametres_eau` VALUES("48", "2020-03-05 11:14:01", "ca", "475");
INSERT INTO `data_parametres_eau` VALUES("49", "2020-03-05 11:16:36", "kh", "7.5");
INSERT INTO `data_parametres_eau` VALUES("50", "2020-03-05 13:04:26", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("51", "2020-03-11 19:33:26", "ca", "450");
INSERT INTO `data_parametres_eau` VALUES("52", "2020-03-11 19:35:59", "kh", "6.5");
INSERT INTO `data_parametres_eau` VALUES("53", "2020-03-11 19:45:35", "mg", "1500");
INSERT INTO `data_parametres_eau` VALUES("54", "2020-03-11 19:47:19", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("55", "2020-03-17 19:00:41", "ca", "440");
INSERT INTO `data_parametres_eau` VALUES("56", "2020-03-17 19:05:37", "kh", "8.6");
INSERT INTO `data_parametres_eau` VALUES("57", "2020-03-17 19:09:57", "mg", "1500");
INSERT INTO `data_parametres_eau` VALUES("58", "2020-03-17 19:10:07", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("59", "2020-03-29 18:53:02", "ca", "450");
INSERT INTO `data_parametres_eau` VALUES("60", "2020-03-29 18:54:57", "kh", "8.7");
INSERT INTO `data_parametres_eau` VALUES("62", "2020-03-29 19:04:32", "densite", "1022");
INSERT INTO `data_parametres_eau` VALUES("63", "2020-03-29 19:21:00", "mg", "1500");
INSERT INTO `data_parametres_eau` VALUES("64", "2020-04-03 21:48:50", "ca", "420");
INSERT INTO `data_parametres_eau` VALUES("65", "2020-04-03 21:48:50", "kh", "6");
INSERT INTO `data_parametres_eau` VALUES("67", "2020-04-03 21:48:50", "densite", "1026");
INSERT INTO `data_parametres_eau` VALUES("68", "2020-04-04 01:03:53", "ca", "450");
INSERT INTO `data_parametres_eau` VALUES("69", "2020-04-04 01:03:53", "kh", "8");
INSERT INTO `data_parametres_eau` VALUES("70", "2020-04-04 01:03:53", "mg", "1300");
INSERT INTO `data_parametres_eau` VALUES("71", "2020-04-04 01:03:53", "densite", "1026");
INSERT INTO `data_parametres_eau` VALUES("72", "2020-05-25 13:03:47", "kh", "8");
INSERT INTO `data_parametres_eau` VALUES("73", "2020-05-25 13:04:01", "kh", "8");


-- --------------------------------------------------------


--
-- Table data_reacteur
--

DROP TABLE IF EXISTS `data_reacteur`;

CREATE TABLE IF NOT EXISTS `data_reacteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `value` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- --------------------------------------------------------


--
-- Table data_temperature
--

DROP TABLE IF EXISTS `data_temperature`;

CREATE TABLE IF NOT EXISTS `data_temperature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `value` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `data_temperature` VALUES("1", "2021-01-24 20:52:26", "25.456");


-- --------------------------------------------------------


--
-- Table data_temperature_boitier
--

DROP TABLE IF EXISTS `data_temperature_boitier`;

CREATE TABLE IF NOT EXISTS `data_temperature_boitier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `value` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `data_temperature_boitier` VALUES("1", "2020-05-08 14:18:51", "29.456");
INSERT INTO `data_temperature_boitier` VALUES("2", "2020-05-08 14:20:27", "29.456");


-- --------------------------------------------------------


--
-- Table last_activity
--

DROP TABLE IF EXISTS `last_activity`;

CREATE TABLE IF NOT EXISTS `last_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `value` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `last_activity` VALUES("1", "2021-01-24 20:52:27", "controle_temperature", "Température");
INSERT INTO `last_activity` VALUES("2", "2020-03-30 19:04:14", "controle_ecumeur", "Écumeur");
INSERT INTO `last_activity` VALUES("3", "2020-03-30 19:04:13", "controle_osmolateur", "Osmolateur");
INSERT INTO `last_activity` VALUES("4", "2020-03-30 19:03:21", "controle_bailling", "Bailling");
INSERT INTO `last_activity` VALUES("5", "2020-03-30 19:04:00", "controle_reacteur", "Réacteur");


-- --------------------------------------------------------


--
-- Table log
--

DROP TABLE IF EXISTS `log`;

CREATE TABLE IF NOT EXISTS `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=849 DEFAULT CHARSET=latin1;

INSERT INTO `log` VALUES("30", "2020-04-12 11:00:25", "Pas de mesure du Ca depuis plus de XX jours !");
INSERT INTO `log` VALUES("31", "2020-04-12 11:00:26", "Pas de mesure du Mg depuis plus de XX jours !");
INSERT INTO `log` VALUES("32", "2020-04-12 11:00:27", "Pas de mesure du Kh depuis plus de XX jours !");
INSERT INTO `log` VALUES("33", "2020-04-12 11:00:28", "Pas de mesure de la densité depuis plus de XX jours !");
INSERT INTO `log` VALUES("34", "2020-04-12 11:01:49", "Pas de mesure du Ca depuis XX jours !");
INSERT INTO `log` VALUES("35", "2020-04-12 11:01:50", "Pas de mesure du Mg depuis XX jours !");
INSERT INTO `log` VALUES("36", "2020-04-12 11:01:51", "Pas de mesure du Kh depuis XX jours !");
INSERT INTO `log` VALUES("37", "2020-04-12 11:01:53", "Pas de mesure de la densité depuis XX jours !");
INSERT INTO `log` VALUES("38", "2020-04-12 11:05:14", "Pas de mesure du Ca depuis XX jours !");
INSERT INTO `log` VALUES("39", "2020-04-12 11:05:15", "Pas de mesure du Mg depuis XX jours !");
INSERT INTO `log` VALUES("40", "2020-04-12 11:05:16", "Pas de mesure du Kh depuis XX jours !");
INSERT INTO `log` VALUES("41", "2020-04-12 11:05:17", "Pas de mesure de la densité depuis XX jours !");
INSERT INTO `log` VALUES("42", "2020-04-12 11:12:16", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("43", "2020-04-12 11:12:17", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("44", "2020-04-12 11:12:18", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("45", "2020-04-12 11:12:19", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("46", "2020-04-12 11:16:37", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("47", "2020-04-12 11:16:38", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("48", "2020-04-12 11:16:39", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("49", "2020-04-12 11:16:40", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("50", "2020-04-12 11:17:29", "Pas de changement d\'eau depuis 0 jours !");
INSERT INTO `log` VALUES("51", "2020-04-12 11:17:30", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("52", "2020-04-12 11:17:31", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("53", "2020-04-12 11:17:32", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("54", "2020-04-12 11:17:33", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("55", "2020-04-12 11:18:09", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("56", "2020-04-12 11:18:10", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("57", "2020-04-12 11:18:11", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("58", "2020-04-12 11:18:12", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("59", "2020-04-12 11:18:14", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("60", "2020-04-12 11:20:54", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("61", "2020-04-12 11:20:55", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("62", "2020-04-12 11:20:57", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("63", "2020-04-12 11:20:58", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("64", "2020-04-12 11:21:00", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("65", "2020-04-12 11:21:35", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("66", "2020-04-12 11:21:36", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("67", "2020-04-12 11:21:37", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("68", "2020-04-12 11:21:38", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("69", "2020-04-12 11:21:39", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("70", "2020-04-12 11:21:40", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("71", "2020-04-12 11:23:59", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("72", "2020-04-12 11:24:00", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("73", "2020-04-12 11:24:01", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("74", "2020-04-12 11:24:02", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("75", "2020-04-12 11:24:03", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("76", "2020-04-12 11:24:05", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("77", "2020-04-12 11:25:04", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("78", "2020-04-12 11:25:08", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("79", "2020-04-12 11:25:09", "L écumeur n\'a pas été nettoyé depuis 0 jours !");
INSERT INTO `log` VALUES("80", "2020-04-12 11:25:10", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("81", "2020-04-12 11:25:11", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("82", "2020-04-12 11:25:12", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("83", "2020-04-12 11:25:13", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("84", "2020-04-12 11:25:46", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("85", "2020-04-12 11:25:47", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("86", "2020-04-12 11:25:48", "L écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("87", "2020-04-12 11:25:50", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("88", "2020-04-12 11:25:51", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("89", "2020-04-12 11:25:52", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("90", "2020-04-12 11:25:53", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("91", "2020-04-12 11:26:07", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("92", "2020-04-12 11:26:08", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("93", "2020-04-12 11:26:09", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("94", "2020-04-12 11:26:10", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("95", "2020-04-12 11:26:11", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("96", "2020-04-12 11:26:12", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("97", "2020-04-12 11:26:13", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("98", "2020-04-12 11:29:04", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("99", "2020-04-12 11:29:05", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("100", "2020-04-12 11:29:08", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("101", "2020-04-12 11:29:09", "Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !");
INSERT INTO `log` VALUES("102", "2020-04-12 11:29:10", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("103", "2020-04-12 11:29:11", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("104", "2020-04-12 11:29:12", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("105", "2020-04-12 11:29:13", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("106", "2020-04-12 13:43:51", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("107", "2020-04-12 13:43:54", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("108", "2020-04-12 13:43:56", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("109", "2020-04-12 13:43:57", "Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !");
INSERT INTO `log` VALUES("110", "2020-04-12 13:43:58", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("111", "2020-04-12 13:43:59", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("112", "2020-04-12 13:44:00", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("113", "2020-04-12 13:44:01", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("114", "2020-04-12 13:51:01", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("115", "2020-04-12 13:51:03", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("116", "2020-04-12 13:51:05", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("117", "2020-04-12 13:51:06", "Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !");
INSERT INTO `log` VALUES("118", "2020-04-12 13:51:07", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("119", "2020-04-12 13:51:08", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("120", "2020-04-12 13:51:09", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("121", "2020-04-12 13:51:10", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("122", "2020-04-12 13:54:02", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("123", "2020-04-12 13:54:03", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("124", "2020-04-12 13:54:04", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("125", "2020-04-12 13:54:05", "Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !");
INSERT INTO `log` VALUES("126", "2020-04-12 13:54:06", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("127", "2020-04-12 13:54:07", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("128", "2020-04-12 13:54:08", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("129", "2020-04-12 13:54:09", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("130", "2020-04-12 13:55:00", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("131", "2020-04-12 13:55:00", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("132", "2020-04-12 13:55:00", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("133", "2020-04-12 13:55:00", "Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !");
INSERT INTO `log` VALUES("134", "2020-04-12 13:55:00", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("135", "2020-04-12 13:55:00", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("136", "2020-04-12 13:55:00", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("137", "2020-04-12 13:55:00", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("138", "2020-04-12 13:59:39", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("139", "2020-04-12 14:00:03", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("140", "2020-04-12 14:00:05", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("141", "2020-04-12 14:00:06", "Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !");
INSERT INTO `log` VALUES("142", "2020-04-12 14:00:07", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("143", "2020-04-12 14:00:08", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("144", "2020-04-12 14:00:09", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("145", "2020-04-12 14:00:11", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("146", "2020-04-12 14:02:01", "Pas de changement d\'eau depuis 39 jours !");
INSERT INTO `log` VALUES("147", "2020-04-12 14:02:01", "Le réacteur n\'a pas été nettoyé depuis 38 jours !");
INSERT INTO `log` VALUES("148", "2020-04-12 14:02:01", "L\'écumeur n\'a pas été nettoyé depuis 73 jours !");
INSERT INTO `log` VALUES("149", "2020-04-12 14:02:01", "Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !");
INSERT INTO `log` VALUES("150", "2020-04-12 14:02:01", "Pas de mesure du Ca depuis 8 jours !");
INSERT INTO `log` VALUES("151", "2020-04-12 14:02:01", "Pas de mesure du Mg depuis 8 jours !");
INSERT INTO `log` VALUES("152", "2020-04-12 14:02:01", "Pas de mesure du Kh depuis 8 jours !");
INSERT INTO `log` VALUES("153", "2020-04-12 14:02:01", "Pas de mesure de la densité depuis 8 jours !");
INSERT INTO `log` VALUES("154", "2020-05-08 14:06:28", "Cron temperature - ERREUR - Le fichier : THERMOMETER_SENSOR_PATH n\'existe pas.");
INSERT INTO `log` VALUES("155", "2020-05-08 14:07:46", "Cron temperature - ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("156", "2020-05-08 14:08:09", "Cron temperature - ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("157", "2020-05-08 14:11:10", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("158", "2020-05-08 14:11:14", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("159", "2020-05-08 14:11:17", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("160", "2020-05-08 14:11:34", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("161", "2020-05-08 14:11:53", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("162", "2020-05-08 14:12:31", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("163", "2020-05-08 14:12:59", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("164", "2020-05-08 14:13:27", "ERREUR - Le fichier : ./test2 n\'existe pas.");
INSERT INTO `log` VALUES("165", "2020-05-08 14:15:24", "Cron temperature - ERREUR - Le fichier : THERMOMETER_SENSOR_PATH n\'existe pas.");
INSERT INTO `log` VALUES("166", "2020-05-12 00:41:09", "Température - Désactivé");
INSERT INTO `log` VALUES("167", "2020-05-12 00:44:51", "Température - Désactivé");
INSERT INTO `log` VALUES("168", "2020-05-12 00:49:45", "Température - Désactivé");
INSERT INTO `log` VALUES("169", "2020-05-12 00:50:50", "Température - Désactivé");
INSERT INTO `log` VALUES("170", "2020-06-21 13:48:47", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("171", "2020-06-21 13:48:47", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("172", "2020-06-21 13:48:47", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("173", "2020-06-21 13:48:47", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("174", "2020-06-21 13:48:47", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("175", "2020-06-21 13:48:47", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("176", "2020-06-21 13:48:47", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("177", "2020-06-21 13:49:13", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("178", "2020-06-21 13:49:13", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("179", "2020-06-21 13:49:13", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("180", "2020-06-21 13:49:13", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("181", "2020-06-21 13:49:13", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("182", "2020-06-21 13:49:13", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("183", "2020-06-21 13:49:13", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("184", "2020-06-21 13:49:21", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("185", "2020-06-21 13:49:21", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("186", "2020-06-21 13:49:21", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("187", "2020-06-21 13:49:21", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("188", "2020-06-21 13:49:21", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("189", "2020-06-21 13:49:21", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("190", "2020-06-21 13:49:21", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("191", "2020-06-21 13:53:09", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("192", "2020-06-21 13:53:09", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("193", "2020-06-21 13:53:09", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("194", "2020-06-21 13:53:09", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("195", "2020-06-21 13:53:09", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("196", "2020-06-21 13:53:09", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("197", "2020-06-21 13:53:09", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("198", "2020-06-21 13:53:51", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("199", "2020-06-21 13:53:51", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("200", "2020-06-21 13:53:51", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("201", "2020-06-21 13:53:51", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("202", "2020-06-21 13:53:51", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("203", "2020-06-21 13:53:51", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("204", "2020-06-21 13:53:51", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("205", "2020-06-21 14:01:47", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("206", "2020-06-21 14:01:47", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("207", "2020-06-21 14:01:47", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("208", "2020-06-21 14:01:47", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("209", "2020-06-21 14:01:47", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("210", "2020-06-21 14:01:47", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("211", "2020-06-21 14:01:47", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("212", "2020-06-21 14:02:06", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("213", "2020-06-21 14:02:06", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("214", "2020-06-21 14:02:06", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("215", "2020-06-21 14:02:06", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("216", "2020-06-21 14:02:06", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("217", "2020-06-21 14:02:06", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("218", "2020-06-21 14:02:06", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("219", "2020-06-21 14:02:20", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("220", "2020-06-21 14:02:20", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("221", "2020-06-21 14:02:20", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("222", "2020-06-21 14:02:20", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("223", "2020-06-21 14:02:20", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("224", "2020-06-21 14:02:20", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("225", "2020-06-21 14:02:20", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("226", "2020-06-21 14:04:24", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("227", "2020-06-21 14:04:24", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("228", "2020-06-21 14:04:24", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("229", "2020-06-21 14:04:24", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("230", "2020-06-21 14:04:24", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("231", "2020-06-21 14:04:24", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("232", "2020-06-21 14:04:24", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("233", "2020-06-21 14:06:24", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("234", "2020-06-21 14:06:24", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("235", "2020-06-21 14:06:24", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("236", "2020-06-21 14:06:24", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("237", "2020-06-21 14:06:24", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("238", "2020-06-21 14:06:24", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("239", "2020-06-21 14:06:24", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("240", "2020-06-21 14:09:04", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("241", "2020-06-21 14:09:04", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("242", "2020-06-21 14:09:04", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("243", "2020-06-21 14:09:04", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("244", "2020-06-21 14:09:04", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("245", "2020-06-21 14:09:04", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("246", "2020-06-21 14:09:04", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("247", "2020-06-21 14:10:09", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("248", "2020-06-21 14:10:09", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("249", "2020-06-21 14:10:09", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("250", "2020-06-21 14:10:09", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("251", "2020-06-21 14:10:09", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("252", "2020-06-21 14:10:09", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("253", "2020-06-21 14:10:09", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("254", "2020-06-21 14:15:49", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("255", "2020-06-21 14:15:49", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("256", "2020-06-21 14:15:49", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("257", "2020-06-21 14:15:49", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("258", "2020-06-21 14:15:49", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("259", "2020-06-21 14:15:49", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("260", "2020-06-21 14:15:49", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("261", "2020-06-21 14:16:39", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("262", "2020-06-21 14:16:39", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("263", "2020-06-21 14:16:39", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("264", "2020-06-21 14:16:39", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("265", "2020-06-21 14:16:39", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("266", "2020-06-21 14:16:39", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("267", "2020-06-21 14:16:39", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("268", "2020-06-21 14:17:02", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("269", "2020-06-21 14:17:02", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("270", "2020-06-21 14:17:02", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("271", "2020-06-21 14:17:02", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("272", "2020-06-21 14:17:02", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("273", "2020-06-21 14:17:02", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("274", "2020-06-21 14:17:02", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("275", "2020-06-21 14:17:19", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("276", "2020-06-21 14:17:19", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("277", "2020-06-21 14:17:19", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("278", "2020-06-21 14:17:19", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("279", "2020-06-21 14:17:19", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("280", "2020-06-21 14:17:19", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("281", "2020-06-21 14:17:19", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("282", "2020-06-21 14:18:36", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("283", "2020-06-21 14:18:36", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("284", "2020-06-21 14:18:36", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("285", "2020-06-21 14:18:36", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("286", "2020-06-21 14:18:36", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("287", "2020-06-21 14:18:36", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("288", "2020-06-21 14:18:36", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("289", "2020-06-21 14:19:18", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("290", "2020-06-21 14:19:18", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("291", "2020-06-21 14:19:18", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("292", "2020-06-21 14:19:18", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("293", "2020-06-21 14:19:18", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("294", "2020-06-21 14:19:18", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("295", "2020-06-21 14:19:18", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("296", "2020-06-21 14:20:03", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("297", "2020-06-21 14:20:03", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("298", "2020-06-21 14:20:03", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("299", "2020-06-21 14:20:03", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("300", "2020-06-21 14:20:03", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("301", "2020-06-21 14:20:03", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("302", "2020-06-21 14:20:03", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("303", "2020-06-21 14:20:39", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("304", "2020-06-21 14:20:39", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("305", "2020-06-21 14:20:39", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("306", "2020-06-21 14:20:40", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("307", "2020-06-21 14:20:40", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("308", "2020-06-21 14:20:40", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("309", "2020-06-21 14:20:40", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("310", "2020-06-21 14:21:03", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("311", "2020-06-21 14:21:03", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("312", "2020-06-21 14:21:03", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("313", "2020-06-21 14:21:03", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("314", "2020-06-21 14:21:03", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("315", "2020-06-21 14:21:03", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("316", "2020-06-21 14:21:03", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("317", "2020-06-21 14:23:49", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("318", "2020-06-21 14:23:49", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("319", "2020-06-21 14:23:49", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("320", "2020-06-21 14:23:49", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("321", "2020-06-21 14:23:49", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("322", "2020-06-21 14:23:49", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("323", "2020-06-21 14:23:49", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("324", "2020-06-21 14:24:42", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("325", "2020-06-21 14:24:42", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("326", "2020-06-21 14:24:42", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("327", "2020-06-21 14:24:42", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("328", "2020-06-21 14:24:42", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("329", "2020-06-21 14:24:42", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("330", "2020-06-21 14:24:42", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("331", "2020-06-21 14:25:50", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("332", "2020-06-21 14:25:50", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("333", "2020-06-21 14:25:50", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("334", "2020-06-21 14:25:50", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("335", "2020-06-21 14:25:50", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("336", "2020-06-21 14:25:50", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("337", "2020-06-21 14:25:50", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("338", "2020-06-21 14:26:08", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("339", "2020-06-21 14:26:08", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("340", "2020-06-21 14:26:08", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("341", "2020-06-21 14:26:08", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("342", "2020-06-21 14:26:08", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("343", "2020-06-21 14:26:08", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("344", "2020-06-21 14:26:08", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("345", "2020-06-21 14:27:20", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("346", "2020-06-21 14:27:20", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("347", "2020-06-21 14:27:20", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("348", "2020-06-21 14:27:20", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("349", "2020-06-21 14:27:20", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("350", "2020-06-21 14:27:20", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("351", "2020-06-21 14:27:20", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("352", "2020-06-21 14:28:14", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("353", "2020-06-21 14:28:14", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("354", "2020-06-21 14:28:14", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("355", "2020-06-21 14:28:14", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("356", "2020-06-21 14:28:14", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("357", "2020-06-21 14:28:14", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("358", "2020-06-21 14:28:14", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("359", "2020-06-21 14:29:10", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("360", "2020-06-21 14:29:10", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("361", "2020-06-21 14:29:10", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("362", "2020-06-21 14:29:10", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("363", "2020-06-21 14:29:10", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("364", "2020-06-21 14:29:10", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("365", "2020-06-21 14:29:10", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("366", "2020-06-21 14:29:41", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("367", "2020-06-21 14:29:41", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("368", "2020-06-21 14:29:41", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("369", "2020-06-21 14:29:41", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("370", "2020-06-21 14:29:41", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("371", "2020-06-21 14:29:41", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("372", "2020-06-21 14:29:41", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("373", "2020-06-21 14:30:27", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("374", "2020-06-21 14:30:27", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("375", "2020-06-21 14:30:27", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("376", "2020-06-21 14:30:27", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("377", "2020-06-21 14:30:27", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("378", "2020-06-21 14:30:27", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("379", "2020-06-21 14:30:27", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("380", "2020-06-21 14:32:48", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("381", "2020-06-21 14:32:48", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("382", "2020-06-21 14:32:48", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("383", "2020-06-21 14:32:48", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("384", "2020-06-21 14:32:48", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("385", "2020-06-21 14:32:48", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("386", "2020-06-21 14:32:48", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("387", "2020-06-21 14:32:56", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("388", "2020-06-21 14:32:56", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("389", "2020-06-21 14:32:56", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("390", "2020-06-21 14:32:56", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("391", "2020-06-21 14:32:56", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("392", "2020-06-21 14:32:56", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("393", "2020-06-21 14:32:56", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("394", "2020-06-21 14:34:40", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("395", "2020-06-21 14:34:40", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("396", "2020-06-21 14:34:40", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("397", "2020-06-21 14:34:40", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("398", "2020-06-21 14:34:40", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("399", "2020-06-21 14:34:40", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("400", "2020-06-21 14:34:40", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("401", "2020-06-21 14:44:48", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("402", "2020-06-21 14:44:48", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("403", "2020-06-21 14:44:48", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("404", "2020-06-21 14:44:48", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("405", "2020-06-21 14:44:48", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("406", "2020-06-21 14:44:48", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("407", "2020-06-21 14:44:48", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("408", "2020-06-21 14:44:56", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("409", "2020-06-21 14:44:56", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("410", "2020-06-21 14:44:56", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("411", "2020-06-21 14:44:56", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("412", "2020-06-21 14:44:56", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("413", "2020-06-21 14:44:56", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("414", "2020-06-21 14:44:56", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("415", "2020-06-21 14:46:10", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("416", "2020-06-21 14:46:10", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("417", "2020-06-21 14:46:10", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("418", "2020-06-21 14:46:10", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("419", "2020-06-21 14:46:10", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("420", "2020-06-21 14:46:10", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("421", "2020-06-21 14:46:10", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("422", "2020-06-21 14:46:13", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("423", "2020-06-21 14:46:13", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("424", "2020-06-21 14:46:13", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("425", "2020-06-21 14:46:13", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("426", "2020-06-21 14:46:13", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("427", "2020-06-21 14:46:13", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("428", "2020-06-21 14:46:13", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("429", "2020-06-21 14:47:05", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("430", "2020-06-21 14:47:05", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("431", "2020-06-21 14:47:05", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("432", "2020-06-21 14:47:05", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("433", "2020-06-21 14:47:05", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("434", "2020-06-21 14:47:05", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("435", "2020-06-21 14:47:05", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("436", "2020-06-21 14:47:30", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("437", "2020-06-21 14:47:30", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("438", "2020-06-21 14:47:30", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("439", "2020-06-21 14:47:30", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("440", "2020-06-21 14:47:30", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("441", "2020-06-21 14:47:30", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("442", "2020-06-21 14:47:30", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("443", "2020-06-21 14:48:50", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("444", "2020-06-21 14:48:50", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("445", "2020-06-21 14:48:50", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("446", "2020-06-21 14:48:50", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("447", "2020-06-21 14:48:50", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("448", "2020-06-21 14:48:50", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("449", "2020-06-21 14:48:50", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("450", "2020-06-21 14:49:42", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("451", "2020-06-21 14:49:42", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("452", "2020-06-21 14:49:42", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("453", "2020-06-21 14:49:42", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("454", "2020-06-21 14:49:42", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("455", "2020-06-21 14:49:42", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("456", "2020-06-21 14:49:42", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("457", "2020-06-21 14:50:45", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("458", "2020-06-21 14:50:45", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("459", "2020-06-21 14:50:45", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("460", "2020-06-21 14:50:45", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("461", "2020-06-21 14:50:45", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("462", "2020-06-21 14:50:45", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("463", "2020-06-21 14:50:45", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("464", "2020-06-21 14:51:02", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("465", "2020-06-21 14:51:02", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("466", "2020-06-21 14:51:02", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("467", "2020-06-21 14:51:02", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("468", "2020-06-21 14:51:02", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("469", "2020-06-21 14:51:02", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("470", "2020-06-21 14:51:02", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("471", "2020-06-21 14:52:19", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("472", "2020-06-21 14:52:19", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("473", "2020-06-21 14:52:19", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("474", "2020-06-21 14:52:19", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("475", "2020-06-21 14:52:19", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("476", "2020-06-21 14:52:19", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("477", "2020-06-21 14:52:19", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("478", "2020-06-21 14:53:49", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("479", "2020-06-21 14:53:49", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("480", "2020-06-21 14:53:49", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("481", "2020-06-21 14:53:49", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("482", "2020-06-21 14:53:49", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("483", "2020-06-21 14:53:49", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("484", "2020-06-21 14:53:49", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("485", "2020-06-21 14:55:28", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("486", "2020-06-21 14:55:28", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("487", "2020-06-21 14:55:28", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("488", "2020-06-21 14:55:28", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("489", "2020-06-21 14:55:28", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("490", "2020-06-21 14:55:28", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("491", "2020-06-21 14:55:28", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("492", "2020-06-21 14:55:58", "Pas de changement d\'eau depuis 45 jours !");
INSERT INTO `log` VALUES("493", "2020-06-21 14:55:58", "Le réacteur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("494", "2020-06-21 14:55:58", "L\'écumeur n\'a pas été nettoyé depuis 45 jours !");
INSERT INTO `log` VALUES("495", "2020-06-21 14:55:58", "Pas de mesure du Ca depuis 78 jours !");
INSERT INTO `log` VALUES("496", "2020-06-21 14:55:58", "Pas de mesure du Mg depuis 78 jours !");
INSERT INTO `log` VALUES("497", "2020-06-21 14:55:58", "Pas de mesure du Kh depuis 27 jours !");
INSERT INTO `log` VALUES("498", "2020-06-21 14:55:58", "Pas de mesure de la densité depuis 78 jours !");
INSERT INTO `log` VALUES("499", "2020-10-09 19:15:35", "Pas de changement d\'eau depuis 155 jours !");
INSERT INTO `log` VALUES("500", "2020-10-09 19:15:35", "Le réacteur n\'a pas été nettoyé depuis 155 jours !");
INSERT INTO `log` VALUES("501", "2020-10-09 19:15:35", "L\'écumeur n\'a pas été nettoyé depuis 155 jours !");
INSERT INTO `log` VALUES("502", "2020-10-09 19:15:35", "Les pompes n\'ont pas été nettoyé depuis depuis 155 jours !");
INSERT INTO `log` VALUES("503", "2020-10-09 19:15:35", "Pas de mesure du Ca depuis 188 jours !");
INSERT INTO `log` VALUES("504", "2020-10-09 19:15:35", "Pas de mesure du Mg depuis 188 jours !");
INSERT INTO `log` VALUES("505", "2020-10-09 19:15:35", "Pas de mesure du Kh depuis 137 jours !");
INSERT INTO `log` VALUES("506", "2020-10-09 19:15:35", "Pas de mesure de la densité depuis 188 jours !");
INSERT INTO `log` VALUES("507", "2020-10-09 19:15:35", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("508", "2020-10-09 19:15:35", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("509", "2020-10-09 19:49:59", "Pas de changement d\'eau depuis 155 jours !");
INSERT INTO `log` VALUES("510", "2020-10-09 19:49:59", "L\'écumeur n\'a pas été nettoyé depuis 155 jours !");
INSERT INTO `log` VALUES("511", "2020-10-09 19:49:59", "Les pompes n\'ont pas été nettoyé depuis depuis 155 jours !");
INSERT INTO `log` VALUES("512", "2020-10-09 19:49:59", "Pas de mesure du Ca depuis 188 jours !");
INSERT INTO `log` VALUES("513", "2020-10-09 19:49:59", "Pas de mesure du Mg depuis 188 jours !");
INSERT INTO `log` VALUES("514", "2020-10-09 19:49:59", "Pas de mesure du Kh depuis 137 jours !");
INSERT INTO `log` VALUES("515", "2020-10-09 19:49:59", "Pas de mesure de la densité depuis 188 jours !");
INSERT INTO `log` VALUES("516", "2020-10-09 19:49:59", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("517", "2020-10-09 19:49:59", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("518", "2020-10-09 20:00:41", "Pas de changement d\'eau depuis 155 jours !");
INSERT INTO `log` VALUES("519", "2020-10-09 20:00:41", "L\'écumeur n\'a pas été nettoyé depuis 155 jours !");
INSERT INTO `log` VALUES("520", "2020-10-09 20:00:41", "Les pompes n\'ont pas été nettoyé depuis depuis 155 jours !");
INSERT INTO `log` VALUES("521", "2020-10-09 20:00:41", "Pas de mesure du Ca depuis 188 jours !");
INSERT INTO `log` VALUES("522", "2020-10-09 20:00:41", "Pas de mesure du Mg depuis 188 jours !");
INSERT INTO `log` VALUES("523", "2020-10-09 20:00:41", "Pas de mesure du Kh depuis 137 jours !");
INSERT INTO `log` VALUES("524", "2020-10-09 20:00:41", "Pas de mesure de la densité depuis 188 jours !");
INSERT INTO `log` VALUES("525", "2020-10-09 20:00:41", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("526", "2020-10-09 20:00:41", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("527", "2020-11-08 21:12:33", "Pas de changement d\'eau depuis 185 jours !");
INSERT INTO `log` VALUES("528", "2020-11-08 21:12:33", "Le réacteur n\'a pas été nettoyé depuis 30 jours !");
INSERT INTO `log` VALUES("529", "2020-11-08 21:12:33", "L\'écumeur n\'a pas été nettoyé depuis 185 jours !");
INSERT INTO `log` VALUES("530", "2020-11-08 21:12:33", "Les pompes n\'ont pas été nettoyé depuis depuis 185 jours !");
INSERT INTO `log` VALUES("531", "2020-11-08 21:12:33", "Pas de mesure du Ca depuis 218 jours !");
INSERT INTO `log` VALUES("532", "2020-11-08 21:12:33", "Pas de mesure du Mg depuis 218 jours !");
INSERT INTO `log` VALUES("533", "2020-11-08 21:12:33", "Pas de mesure du Kh depuis 167 jours !");
INSERT INTO `log` VALUES("534", "2020-11-08 21:12:33", "Pas de mesure de la densité depuis 218 jours !");
INSERT INTO `log` VALUES("535", "2020-11-08 21:12:33", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("536", "2020-11-08 21:12:33", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("537", "2020-11-13 13:47:12", "Pas de changement d\'eau depuis 190 jours !");
INSERT INTO `log` VALUES("538", "2020-11-13 13:47:12", "Le réacteur n\'a pas été nettoyé depuis 35 jours !");
INSERT INTO `log` VALUES("539", "2020-11-13 13:47:12", "L\'écumeur n\'a pas été nettoyé depuis 190 jours !");
INSERT INTO `log` VALUES("540", "2020-11-13 13:47:12", "Les pompes n\'ont pas été nettoyé depuis depuis 190 jours !");
INSERT INTO `log` VALUES("541", "2020-11-13 13:47:12", "Pas de mesure du Ca depuis 223 jours !");
INSERT INTO `log` VALUES("542", "2020-11-13 13:47:12", "Pas de mesure du Mg depuis 223 jours !");
INSERT INTO `log` VALUES("543", "2020-11-13 13:47:12", "Pas de mesure du Kh depuis 172 jours !");
INSERT INTO `log` VALUES("544", "2020-11-13 13:47:12", "Pas de mesure de la densité depuis 223 jours !");
INSERT INTO `log` VALUES("545", "2020-11-13 13:47:12", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("546", "2020-11-13 13:47:12", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("547", "2020-12-04 19:42:54", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("548", "2020-12-04 19:42:55", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("549", "2020-12-04 19:42:55", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("550", "2020-12-04 19:42:55", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("551", "2020-12-04 19:42:55", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("552", "2020-12-04 19:42:55", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("553", "2020-12-04 19:42:55", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("554", "2020-12-04 19:42:55", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("555", "2020-12-04 19:42:55", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("556", "2020-12-04 19:42:55", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("557", "2020-12-04 19:42:55", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("558", "2020-12-04 19:42:55", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("559", "2020-12-04 19:42:55", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("560", "2020-12-04 19:42:55", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("561", "2020-12-04 19:42:55", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("562", "2020-12-04 19:42:55", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("563", "2020-12-04 19:42:55", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("564", "2020-12-04 19:42:55", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("565", "2020-12-04 19:42:55", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("566", "2020-12-04 19:42:55", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("567", "2020-12-04 19:43:16", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("568", "2020-12-04 19:43:16", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("569", "2020-12-04 19:43:16", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("570", "2020-12-04 19:43:16", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("571", "2020-12-04 19:43:16", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("572", "2020-12-04 19:43:16", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("573", "2020-12-04 19:43:16", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("574", "2020-12-04 19:43:16", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("575", "2020-12-04 19:43:16", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("576", "2020-12-04 19:43:16", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("577", "2020-12-04 19:46:25", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("578", "2020-12-04 19:46:25", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("579", "2020-12-04 19:46:25", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("580", "2020-12-04 19:46:25", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("581", "2020-12-04 19:46:25", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("582", "2020-12-04 19:46:25", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("583", "2020-12-04 19:46:25", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("584", "2020-12-04 19:46:25", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("585", "2020-12-04 19:46:25", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("586", "2020-12-04 19:46:25", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("587", "2020-12-04 19:46:42", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("588", "2020-12-04 19:46:42", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("589", "2020-12-04 19:46:42", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("590", "2020-12-04 19:46:42", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("591", "2020-12-04 19:46:42", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("592", "2020-12-04 19:46:42", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("593", "2020-12-04 19:46:42", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("594", "2020-12-04 19:46:42", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("595", "2020-12-04 19:46:42", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("596", "2020-12-04 19:46:42", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("597", "2020-12-04 19:52:14", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("598", "2020-12-04 19:52:14", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("599", "2020-12-04 19:52:14", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("600", "2020-12-04 19:52:14", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("601", "2020-12-04 19:52:14", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("602", "2020-12-04 19:52:14", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("603", "2020-12-04 19:52:14", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("604", "2020-12-04 19:52:14", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("605", "2020-12-04 19:52:14", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("606", "2020-12-04 19:52:14", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("607", "2020-12-04 19:56:21", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("608", "2020-12-04 19:56:21", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("609", "2020-12-04 19:56:21", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("610", "2020-12-04 19:56:21", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("611", "2020-12-04 19:56:21", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("612", "2020-12-04 19:56:21", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("613", "2020-12-04 19:56:21", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("614", "2020-12-04 19:56:21", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("615", "2020-12-04 19:56:21", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("616", "2020-12-04 19:56:21", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("617", "2020-12-04 19:56:28", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("618", "2020-12-04 19:56:28", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("619", "2020-12-04 19:56:28", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("620", "2020-12-04 19:56:28", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("621", "2020-12-04 19:56:28", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("622", "2020-12-04 19:56:28", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("623", "2020-12-04 19:56:28", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("624", "2020-12-04 19:56:28", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("625", "2020-12-04 19:56:28", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("626", "2020-12-04 19:56:28", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("627", "2020-12-04 19:57:09", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("628", "2020-12-04 19:57:09", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("629", "2020-12-04 19:57:09", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("630", "2020-12-04 19:57:09", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("631", "2020-12-04 19:57:09", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("632", "2020-12-04 19:57:09", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("633", "2020-12-04 19:57:09", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("634", "2020-12-04 19:57:09", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("635", "2020-12-04 19:57:09", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("636", "2020-12-04 19:57:09", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("637", "2020-12-04 19:57:14", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("638", "2020-12-04 19:57:14", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("639", "2020-12-04 19:57:14", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("640", "2020-12-04 19:57:14", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("641", "2020-12-04 19:57:14", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("642", "2020-12-04 19:57:14", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("643", "2020-12-04 19:57:14", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("644", "2020-12-04 19:57:14", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("645", "2020-12-04 19:57:14", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("646", "2020-12-04 19:57:14", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("647", "2020-12-04 19:58:10", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("648", "2020-12-04 19:58:10", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("649", "2020-12-04 19:58:10", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("650", "2020-12-04 19:58:10", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("651", "2020-12-04 19:58:10", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("652", "2020-12-04 19:58:10", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("653", "2020-12-04 19:58:10", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("654", "2020-12-04 19:58:10", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("655", "2020-12-04 19:58:10", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("656", "2020-12-04 19:58:10", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("657", "2020-12-04 19:59:49", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("658", "2020-12-04 19:59:49", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("659", "2020-12-04 19:59:49", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("660", "2020-12-04 19:59:49", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("661", "2020-12-04 19:59:49", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("662", "2020-12-04 19:59:49", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("663", "2020-12-04 19:59:49", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("664", "2020-12-04 19:59:49", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("665", "2020-12-04 19:59:49", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("666", "2020-12-04 19:59:49", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("667", "2020-12-04 20:00:33", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("668", "2020-12-04 20:00:33", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("669", "2020-12-04 20:00:33", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("670", "2020-12-04 20:00:33", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("671", "2020-12-04 20:00:33", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("672", "2020-12-04 20:00:33", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("673", "2020-12-04 20:00:33", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("674", "2020-12-04 20:00:33", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("675", "2020-12-04 20:00:33", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("676", "2020-12-04 20:00:33", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("677", "2020-12-04 20:01:04", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("678", "2020-12-04 20:01:04", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("679", "2020-12-04 20:01:04", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("680", "2020-12-04 20:01:04", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("681", "2020-12-04 20:01:04", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("682", "2020-12-04 20:01:04", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("683", "2020-12-04 20:01:04", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("684", "2020-12-04 20:01:04", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("685", "2020-12-04 20:01:04", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("686", "2020-12-04 20:01:04", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("687", "2020-12-04 20:01:39", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("688", "2020-12-04 20:01:39", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("689", "2020-12-04 20:01:39", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("690", "2020-12-04 20:01:39", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("691", "2020-12-04 20:01:39", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("692", "2020-12-04 20:01:39", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("693", "2020-12-04 20:01:39", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("694", "2020-12-04 20:01:39", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("695", "2020-12-04 20:01:39", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("696", "2020-12-04 20:01:39", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("697", "2020-12-04 20:01:59", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("698", "2020-12-04 20:01:59", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("699", "2020-12-04 20:01:59", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("700", "2020-12-04 20:01:59", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("701", "2020-12-04 20:01:59", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("702", "2020-12-04 20:01:59", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("703", "2020-12-04 20:01:59", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("704", "2020-12-04 20:01:59", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("705", "2020-12-04 20:01:59", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("706", "2020-12-04 20:01:59", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("707", "2020-12-04 20:03:49", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("708", "2020-12-04 20:03:49", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("709", "2020-12-04 20:03:49", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("710", "2020-12-04 20:03:49", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("711", "2020-12-04 20:03:49", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("712", "2020-12-04 20:03:49", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("713", "2020-12-04 20:03:49", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("714", "2020-12-04 20:03:49", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("715", "2020-12-04 20:03:49", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("716", "2020-12-04 20:03:49", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("717", "2020-12-04 20:04:22", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("718", "2020-12-04 20:04:22", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("719", "2020-12-04 20:04:22", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("720", "2020-12-04 20:04:22", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("721", "2020-12-04 20:04:22", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("722", "2020-12-04 20:04:22", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("723", "2020-12-04 20:04:22", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("724", "2020-12-04 20:04:22", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("725", "2020-12-04 20:04:22", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("726", "2020-12-04 20:04:22", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("727", "2020-12-04 20:04:25", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("728", "2020-12-04 20:04:25", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("729", "2020-12-04 20:04:25", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("730", "2020-12-04 20:04:25", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("731", "2020-12-04 20:04:25", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("732", "2020-12-04 20:04:25", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("733", "2020-12-04 20:04:25", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("734", "2020-12-04 20:04:25", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("735", "2020-12-04 20:04:25", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("736", "2020-12-04 20:04:25", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("737", "2020-12-04 20:04:27", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("738", "2020-12-04 20:04:27", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("739", "2020-12-04 20:04:27", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("740", "2020-12-04 20:04:27", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("741", "2020-12-04 20:04:27", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("742", "2020-12-04 20:04:27", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("743", "2020-12-04 20:04:27", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("744", "2020-12-04 20:04:27", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("745", "2020-12-04 20:04:27", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("746", "2020-12-04 20:04:27", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("747", "2020-12-04 20:04:48", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("748", "2020-12-04 20:04:48", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("749", "2020-12-04 20:04:48", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("750", "2020-12-04 20:04:48", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("751", "2020-12-04 20:04:48", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("752", "2020-12-04 20:04:48", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("753", "2020-12-04 20:04:48", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("754", "2020-12-04 20:04:48", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("755", "2020-12-04 20:04:48", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("756", "2020-12-04 20:04:48", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("757", "2020-12-04 20:07:11", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("758", "2020-12-04 20:07:11", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("759", "2020-12-04 20:07:11", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("760", "2020-12-04 20:07:11", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("761", "2020-12-04 20:07:11", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("762", "2020-12-04 20:07:11", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("763", "2020-12-04 20:07:11", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("764", "2020-12-04 20:07:11", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("765", "2020-12-04 20:07:11", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("766", "2020-12-04 20:07:11", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("767", "2020-12-04 20:07:12", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("768", "2020-12-04 20:07:12", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("769", "2020-12-04 20:07:12", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("770", "2020-12-04 20:07:12", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("771", "2020-12-04 20:07:12", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("772", "2020-12-04 20:07:12", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("773", "2020-12-04 20:07:12", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("774", "2020-12-04 20:07:12", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("775", "2020-12-04 20:07:12", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("776", "2020-12-04 20:07:12", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("777", "2020-12-04 20:07:21", "Pas de changement d\'eau depuis 211 jours !");
INSERT INTO `log` VALUES("778", "2020-12-04 20:07:21", "Le réacteur n\'a pas été nettoyé depuis 56 jours !");
INSERT INTO `log` VALUES("779", "2020-12-04 20:07:21", "L\'écumeur n\'a pas été nettoyé depuis 211 jours !");
INSERT INTO `log` VALUES("780", "2020-12-04 20:07:21", "Les pompes n\'ont pas été nettoyé depuis depuis 211 jours !");
INSERT INTO `log` VALUES("781", "2020-12-04 20:07:21", "Pas de mesure du Ca depuis 244 jours !");
INSERT INTO `log` VALUES("782", "2020-12-04 20:07:21", "Pas de mesure du Mg depuis 244 jours !");
INSERT INTO `log` VALUES("783", "2020-12-04 20:07:21", "Pas de mesure du Kh depuis 193 jours !");
INSERT INTO `log` VALUES("784", "2020-12-04 20:07:21", "Pas de mesure de la densité depuis 244 jours !");
INSERT INTO `log` VALUES("785", "2020-12-04 20:07:21", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("786", "2020-12-04 20:07:21", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("787", "2021-01-24 19:55:54", "Pas de changement d\'eau depuis 262 jours !");
INSERT INTO `log` VALUES("788", "2021-01-24 19:55:54", "Le réacteur n\'a pas été nettoyé depuis 107 jours !");
INSERT INTO `log` VALUES("789", "2021-01-24 19:55:54", "L\'écumeur n\'a pas été nettoyé depuis 262 jours !");
INSERT INTO `log` VALUES("790", "2021-01-24 19:55:54", "Les pompes n\'ont pas été nettoyé depuis depuis 262 jours !");
INSERT INTO `log` VALUES("791", "2021-01-24 19:55:54", "Pas de mesure du Ca depuis 295 jours !");
INSERT INTO `log` VALUES("792", "2021-01-24 19:55:54", "Pas de mesure du Mg depuis 295 jours !");
INSERT INTO `log` VALUES("793", "2021-01-24 19:55:54", "Pas de mesure du Kh depuis 244 jours !");
INSERT INTO `log` VALUES("794", "2021-01-24 19:55:54", "Pas de mesure de la densité depuis 295 jours !");
INSERT INTO `log` VALUES("795", "2021-01-24 19:55:54", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("796", "2021-01-24 19:55:54", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("797", "2021-01-24 20:02:50", "Cron temperature - ERREUR - Le fichier : THERMOMETER_SENSOR_PATH n\'existe pas.");
INSERT INTO `log` VALUES("798", "2021-01-24 20:14:21", "Pas de changement d\'eau depuis 262 jours !");
INSERT INTO `log` VALUES("799", "2021-01-24 20:14:21", "Le réacteur n\'a pas été nettoyé depuis 107 jours !");
INSERT INTO `log` VALUES("800", "2021-01-24 20:14:21", "L\'écumeur n\'a pas été nettoyé depuis 262 jours !");
INSERT INTO `log` VALUES("801", "2021-01-24 20:14:21", "Les pompes n\'ont pas été nettoyé depuis depuis 262 jours !");
INSERT INTO `log` VALUES("802", "2021-01-24 20:14:21", "Pas de mesure du Ca depuis 295 jours !");
INSERT INTO `log` VALUES("803", "2021-01-24 20:14:21", "Pas de mesure du Mg depuis 295 jours !");
INSERT INTO `log` VALUES("804", "2021-01-24 20:14:21", "Pas de mesure du Kh depuis 244 jours !");
INSERT INTO `log` VALUES("805", "2021-01-24 20:14:21", "Pas de mesure de la densité depuis 295 jours !");
INSERT INTO `log` VALUES("806", "2021-01-24 20:14:21", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("807", "2021-01-24 20:14:21", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("808", "2021-01-24 20:29:27", "Pas de changement d\'eau depuis 262 jours !");
INSERT INTO `log` VALUES("809", "2021-01-24 20:29:27", "Le réacteur n\'a pas été nettoyé depuis 107 jours !");
INSERT INTO `log` VALUES("810", "2021-01-24 20:29:27", "L\'écumeur n\'a pas été nettoyé depuis 262 jours !");
INSERT INTO `log` VALUES("811", "2021-01-24 20:29:27", "Les pompes n\'ont pas été nettoyé depuis depuis 262 jours !");
INSERT INTO `log` VALUES("812", "2021-01-24 20:29:27", "Pas de mesure du Ca depuis 295 jours !");
INSERT INTO `log` VALUES("813", "2021-01-24 20:29:27", "Pas de mesure du Mg depuis 295 jours !");
INSERT INTO `log` VALUES("814", "2021-01-24 20:29:27", "Pas de mesure du Kh depuis 244 jours !");
INSERT INTO `log` VALUES("815", "2021-01-24 20:29:27", "Pas de mesure de la densité depuis 295 jours !");
INSERT INTO `log` VALUES("816", "2021-01-24 20:29:27", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("817", "2021-01-24 20:29:27", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("818", "2021-01-24 20:38:20", "Pas de changement d\'eau depuis 262 jours !");
INSERT INTO `log` VALUES("819", "2021-01-24 20:38:20", "Le réacteur n\'a pas été nettoyé depuis 107 jours !");
INSERT INTO `log` VALUES("820", "2021-01-24 20:38:20", "L\'écumeur n\'a pas été nettoyé depuis 262 jours !");
INSERT INTO `log` VALUES("821", "2021-01-24 20:38:20", "Les pompes n\'ont pas été nettoyé depuis depuis 262 jours !");
INSERT INTO `log` VALUES("822", "2021-01-24 20:38:20", "Pas de mesure du Ca depuis 295 jours !");
INSERT INTO `log` VALUES("823", "2021-01-24 20:38:20", "Pas de mesure du Mg depuis 295 jours !");
INSERT INTO `log` VALUES("824", "2021-01-24 20:38:20", "Pas de mesure du Kh depuis 244 jours !");
INSERT INTO `log` VALUES("825", "2021-01-24 20:38:20", "Pas de mesure de la densité depuis 295 jours !");
INSERT INTO `log` VALUES("826", "2021-01-24 20:38:20", "Pas de mesure de nitrate depuis 0 jours !");
INSERT INTO `log` VALUES("827", "2021-01-24 20:38:20", "Pas de mesure de phosphate depuis 0 jours !");
INSERT INTO `log` VALUES("828", "2021-01-24 20:45:14", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("829", "2021-01-24 20:45:14", "Cron temperature - ERREUR - Format du fichier incorrect ()");
INSERT INTO `log` VALUES("830", "2021-01-24 20:46:29", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("831", "2021-01-24 20:46:29", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("832", "2021-01-24 20:46:29", "Cron temperature - ERREUR - Format du fichier incorrect ()");
INSERT INTO `log` VALUES("833", "2021-01-24 20:46:34", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("834", "2021-01-24 20:46:34", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("835", "2021-01-24 20:46:34", "Cron temperature - ERREUR - Format du fichier incorrect ()");
INSERT INTO `log` VALUES("836", "2021-01-24 20:46:53", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("837", "2021-01-24 20:46:53", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("838", "2021-01-24 20:47:58", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("839", "2021-01-24 20:47:58", "Cron temperature - ERREUR - Format du fichier incorrect ()");
INSERT INTO `log` VALUES("840", "2021-01-24 20:48:46", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("841", "2021-01-24 20:48:46", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("842", "2021-01-24 20:48:46", "Cron temperature - ERREUR - Format du fichier incorrect ()");
INSERT INTO `log` VALUES("843", "2021-01-24 20:51:46", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("844", "2021-01-24 20:51:46", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("845", "2021-01-24 20:51:46", "Cron temperature - ERREUR - Format du fichier incorrect ()");
INSERT INTO `log` VALUES("846", "2021-01-24 20:51:52", "ERREUR - Le fichier : /Users/alex/www/aqua/test n\'existe pas.");
INSERT INTO `log` VALUES("847", "2021-01-24 20:52:26", "Temperature - OK - 25.456°C");
INSERT INTO `log` VALUES("848", "2021-01-24 21:53:46", "Unable to open file for reading [{$file}.zip]");


-- --------------------------------------------------------


--
-- Table log_mail
--

DROP TABLE IF EXISTS `log_mail`;

CREATE TABLE IF NOT EXISTS `log_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sujet` text CHARACTER SET utf8 NOT NULL,
  `message` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=latin1;

INSERT INTO `log_mail` VALUES("25", "2020-04-12 11:00:23", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("26", "2020-04-12 11:00:25", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis plus de XX jours !</p>");
INSERT INTO `log_mail` VALUES("27", "2020-04-12 11:00:26", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis plus de XX jours !</p>");
INSERT INTO `log_mail` VALUES("28", "2020-04-12 11:00:27", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis plus de XX jours !</p>");
INSERT INTO `log_mail` VALUES("29", "2020-04-12 11:00:28", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis plus de XX jours !</p>");
INSERT INTO `log_mail` VALUES("30", "2020-04-12 11:01:48", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("31", "2020-04-12 11:01:49", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("32", "2020-04-12 11:01:50", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("33", "2020-04-12 11:01:51", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("34", "2020-04-12 11:01:53", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("35", "2020-04-12 11:05:13", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("36", "2020-04-12 11:05:14", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("37", "2020-04-12 11:05:15", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("38", "2020-04-12 11:05:16", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("39", "2020-04-12 11:05:17", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis XX jours !</p>");
INSERT INTO `log_mail` VALUES("40", "2020-04-12 11:12:14", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("41", "2020-04-12 11:12:16", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("42", "2020-04-12 11:12:17", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("43", "2020-04-12 11:12:18", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("44", "2020-04-12 11:12:19", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("45", "2020-04-12 11:16:36", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("46", "2020-04-12 11:16:37", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("47", "2020-04-12 11:16:38", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("48", "2020-04-12 11:16:39", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("49", "2020-04-12 11:16:40", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("50", "2020-04-12 11:17:28", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("51", "2020-04-12 11:17:29", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 0 jours !</p>");
INSERT INTO `log_mail` VALUES("52", "2020-04-12 11:17:30", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("53", "2020-04-12 11:17:31", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("54", "2020-04-12 11:17:32", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("55", "2020-04-12 11:17:33", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("56", "2020-04-12 11:18:08", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("57", "2020-04-12 11:18:09", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("58", "2020-04-12 11:18:10", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("59", "2020-04-12 11:18:11", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("60", "2020-04-12 11:18:12", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("61", "2020-04-12 11:18:14", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("62", "2020-04-12 11:20:53", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("63", "2020-04-12 11:20:54", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("64", "2020-04-12 11:20:55", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("65", "2020-04-12 11:20:57", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("66", "2020-04-12 11:20:58", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("67", "2020-04-12 11:21:00", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("68", "2020-04-12 11:21:34", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("69", "2020-04-12 11:21:35", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("70", "2020-04-12 11:21:36", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("71", "2020-04-12 11:21:37", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("72", "2020-04-12 11:21:38", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("73", "2020-04-12 11:21:39", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("74", "2020-04-12 11:21:40", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("75", "2020-04-12 11:23:58", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("76", "2020-04-12 11:23:59", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("77", "2020-04-12 11:24:00", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("78", "2020-04-12 11:24:01", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("79", "2020-04-12 11:24:02", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("80", "2020-04-12 11:24:03", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("81", "2020-04-12 11:24:05", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("82", "2020-04-12 11:25:03", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("83", "2020-04-12 11:25:04", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("84", "2020-04-12 11:25:08", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("85", "2020-04-12 11:25:09", "Rappel - nettoyer l écumeur", "<p style=\'color: red;\'>L écumeur n\'a pas été nettoyé depuis 0 jours !</p>");
INSERT INTO `log_mail` VALUES("86", "2020-04-12 11:25:10", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("87", "2020-04-12 11:25:11", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("88", "2020-04-12 11:25:12", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("89", "2020-04-12 11:25:13", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("90", "2020-04-12 11:25:45", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("91", "2020-04-12 11:25:46", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("92", "2020-04-12 11:25:47", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("93", "2020-04-12 11:25:48", "Rappel - nettoyer l écumeur", "<p style=\'color: red;\'>L écumeur n\'a pas été nettoyé depuis 73 jours !</p>");
INSERT INTO `log_mail` VALUES("94", "2020-04-12 11:25:50", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("95", "2020-04-12 11:25:51", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("96", "2020-04-12 11:25:52", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("97", "2020-04-12 11:25:53", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("98", "2020-04-12 11:26:06", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("99", "2020-04-12 11:26:07", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("100", "2020-04-12 11:26:08", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("101", "2020-04-12 11:26:09", "Rappel - nettoyer l\'écumeur", "<p style=\'color: red;\'>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p>");
INSERT INTO `log_mail` VALUES("102", "2020-04-12 11:26:10", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("103", "2020-04-12 11:26:11", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("104", "2020-04-12 11:26:12", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("105", "2020-04-12 11:26:13", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("106", "2020-04-12 11:29:03", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("107", "2020-04-12 11:29:04", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("108", "2020-04-12 11:29:05", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("109", "2020-04-12 11:29:08", "Rappel - nettoyer l\'écumeur", "<p style=\'color: red;\'>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p>");
INSERT INTO `log_mail` VALUES("110", "2020-04-12 11:29:09", "Rappel - nettoyer les pompes", "<p style=\'color: red;\'>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p>");
INSERT INTO `log_mail` VALUES("111", "2020-04-12 11:29:10", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("112", "2020-04-12 11:29:11", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("113", "2020-04-12 11:29:12", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("114", "2020-04-12 11:29:13", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("115", "2020-04-12 13:43:50", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("116", "2020-04-12 13:43:51", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("117", "2020-04-12 13:43:54", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("118", "2020-04-12 13:43:56", "Rappel - nettoyer l\'écumeur", "<p style=\'color: red;\'>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p>");
INSERT INTO `log_mail` VALUES("119", "2020-04-12 13:43:57", "Rappel - nettoyer les pompes", "<p style=\'color: red;\'>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p>");
INSERT INTO `log_mail` VALUES("120", "2020-04-12 13:43:58", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("121", "2020-04-12 13:43:59", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("122", "2020-04-12 13:44:00", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("123", "2020-04-12 13:44:01", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("124", "2020-04-12 13:51:01", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("125", "2020-04-12 13:51:03", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("126", "2020-04-12 13:51:05", "Rappel - nettoyer l\'écumeur", "<p style=\'color: red;\'>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p>");
INSERT INTO `log_mail` VALUES("127", "2020-04-12 13:51:06", "Rappel - nettoyer les pompes", "<p style=\'color: red;\'>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p>");
INSERT INTO `log_mail` VALUES("128", "2020-04-12 13:51:07", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("129", "2020-04-12 13:51:08", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("130", "2020-04-12 13:51:09", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("131", "2020-04-12 13:51:10", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("132", "2020-04-12 13:51:11", "Cron - contrôle 8h - OK", "<p style=\'color:green;text-transform:none;\'>Cron - contrôle 8h - OK</p><p>Dernier débit enregistré : 1489 l/min</p><p>Dernière température enregistrée : 24.69 °C</p><p>Pas de changement d\'eau depuis 39 jours !</p><p>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p><p>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p><p>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p><p>Pas de mesure du Ca depuis 8 jours !</p><p>Pas de mesure du Mg depuis 8 jours !</p><p>Pas de mesure du Kh depuis 8 jours !</p><p>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("133", "2020-04-12 13:54:02", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("134", "2020-04-12 13:54:03", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("135", "2020-04-12 13:54:04", "Rappel - nettoyer l\'écumeur", "<p style=\'color: red;\'>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p>");
INSERT INTO `log_mail` VALUES("136", "2020-04-12 13:54:05", "Rappel - nettoyer les pompes", "<p style=\'color: red;\'>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p>");
INSERT INTO `log_mail` VALUES("137", "2020-04-12 13:54:06", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("138", "2020-04-12 13:54:07", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("139", "2020-04-12 13:54:08", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("140", "2020-04-12 13:54:09", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("141", "2020-04-12 13:54:10", "Cron - contrôle 8h - OK", "<p style=\'color:green;text-transform:none;\'>Cron - contrôle 8h - OK</p><p>Dernier débit enregistré : 1489 l/min</p><p>Dernière température enregistrée : 24.69 °C</p><p>Pas de changement d\'eau depuis 39 jours !</p><p>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p><p>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p><p>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p><p>Pas de mesure du Ca depuis 8 jours !</p><p>Pas de mesure du Mg depuis 8 jours !</p><p>Pas de mesure du Kh depuis 8 jours !</p><p>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("142", "2020-04-12 13:55:02", "Cron - contrôle 8h - OK", "<p style=\'color:green;text-transform:none;\'>Cron - contrôle 8h - OK</p><p>Dernier débit enregistré : 1489 l/min</p><p>Dernière température enregistrée : 24.69 °C</p><p>Pas de changement d\'eau depuis 39 jours !</p><p>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p><p>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p><p>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p><p>Pas de mesure du Ca depuis 8 jours !</p><p>Pas de mesure du Mg depuis 8 jours !</p><p>Pas de mesure du Kh depuis 8 jours !</p><p>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("143", "2020-04-12 13:59:37", "Rappel - ajout à faire", "<p style=\'color: #3a87ad;\'>Nourriture congelée</p>");
INSERT INTO `log_mail` VALUES("144", "2020-04-12 13:59:39", "Rappel - faire un changement d\'eau", "<p style=\'color: red;\'>Pas de changement d\'eau depuis 39 jours !</p>");
INSERT INTO `log_mail` VALUES("145", "2020-04-12 14:00:03", "Rappel - nettoyer le reacteur", "<p style=\'color: red;\'>Le réacteur n\'a pas été nettoyé depuis 38 jours !</p>");
INSERT INTO `log_mail` VALUES("146", "2020-04-12 14:00:05", "Rappel - nettoyer l\'écumeur", "<p style=\'color: red;\'>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</p>");
INSERT INTO `log_mail` VALUES("147", "2020-04-12 14:00:06", "Rappel - nettoyer les pompes", "<p style=\'color: red;\'>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</p>");
INSERT INTO `log_mail` VALUES("148", "2020-04-12 14:00:07", "Rappel - faire une mesure du Ca", "<p style=\'color: red;\'>Pas de mesure du Ca depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("149", "2020-04-12 14:00:08", "Rappel - faire une mesure du Mg", "<p style=\'color: red;\'>Pas de mesure du Mg depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("150", "2020-04-12 14:00:09", "Rappel - faire une mesure du Kh", "<p style=\'color: red;\'>Pas de mesure du Kh depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("151", "2020-04-12 14:00:11", "Rappel - faire une mesure de la densité", "<p style=\'color: red;\'>Pas de mesure de la densité depuis 8 jours !</p>");
INSERT INTO `log_mail` VALUES("152", "2020-04-12 14:02:03", "Cron - contrôle 8h - OK", "<p style=\'color:green;text-transform:none;\'>Cron - contrôle 8h - OK</p><p>Dernier débit enregistré : 1489 l/min</p><p>Dernière température enregistrée : 24.69 °C</p><p>RAPPEL À FAIRE :</p><ul><li>Pas de changement d\'eau depuis 39 jours !</li><li>Le réacteur n\'a pas été nettoyé depuis 38 jours !</li><li>L\'écumeur n\'a pas été nettoyé depuis 73 jours !</li><li>Les pompes n\'ont pas été nettoyé depuis depuis 131 jours !</li><li>Pas de mesure du Ca depuis 8 jours !</li><li>Pas de mesure du Mg depuis 8 jours !</li><li>Pas de mesure du Kh depuis 8 jours !</li><li>Pas de mesure de la densité depuis 8 jours !</li></ul>");
INSERT INTO `log_mail` VALUES("153", "2020-06-02 18:37:53", "Le changement d\'eau a été sauvegardé.", "Le changement d\'eau a été sauvegardé.");
INSERT INTO `log_mail` VALUES("154", "2020-06-02 18:40:15", "Le changement d\'eau a été supprimé.", "Le changement d\'eau a été supprimé.");
INSERT INTO `log_mail` VALUES("155", "2020-06-02 18:42:24", "Validation du formulaire de changement de statut.", "Validation du formulaire de changement de statut.");
INSERT INTO `log_mail` VALUES("156", "2020-06-02 18:42:28", "Les configurations ont été sauvegardé.", "Les configurations ont été sauvegardé.");
INSERT INTO `log_mail` VALUES("157", "2020-06-12 13:51:29", "Le changement d\'eau a été supprimé.", "Le changement d\'eau a été supprimé.");
INSERT INTO `log_mail` VALUES("158", "2020-10-09 19:15:49", "Le réacteur a été marqué comme nettoyé.", "Le réacteur a été marqué comme nettoyé.");
INSERT INTO `log_mail` VALUES("159", "2020-10-09 19:16:08", "Le réacteur a été marqué comme nettoyé.", "Le réacteur a été marqué comme nettoyé.");
INSERT INTO `log_mail` VALUES("160", "2021-01-24 21:53:46", "Error script dump.php", "Unable to open file for reading [{$file}.zip]");


-- --------------------------------------------------------


--
-- Table state
--

DROP TABLE IF EXISTS `state`;

CREATE TABLE IF NOT EXISTS `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `path` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `message` text,
  `mail_send` tinyint(1) NOT NULL DEFAULT '0',
  `exclude_check` tinyint(1) NOT NULL DEFAULT '1',
  `label` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `state` VALUES("1", "2020-03-29 19:10:01", "controle_bailling", "state_1", "0", "Cron controle controle_bailling - OK", "1", "0", "Cron bailling");
INSERT INTO `state` VALUES("2", "2020-03-29 19:10:02", "controle_osmolateur", "state_1", "0", "Cron controle controle_osmolateur - OK", "1", "0", "Cron osmolateur");
INSERT INTO `state` VALUES("3", "2020-03-29 19:10:03", "controle_temperature", "state_1", "0", "Cron controle controle_temperature - OK", "1", "0", "Cron température");
INSERT INTO `state` VALUES("4", "2020-03-29 19:10:04", "controle_reacteur", "state_1", "0", "Cron controle controle_reacteur - OK", "1", "0", "Cron réacteur");
INSERT INTO `state` VALUES("5", "2020-03-29 19:10:05", "controle_ecumeur", "state_1", "0", "Cron controle controle_ecumeur - OK", "1", "0", "Cron écumeur");
INSERT INTO `state` VALUES("6", "2020-02-03 23:09:09", "controle", "state_1", "0", "Cron controle - OK", "0", "1", "");
INSERT INTO `state` VALUES("7", "2021-01-24 20:52:26", "temperature", "state_7", "0", "Temperature - OK - 25.456°C", "0", "0", "Température");
INSERT INTO `state` VALUES("8", "2020-03-30 13:38:19", "ecumeur", "state_2", "0", "Ecumeur - niveau godet OK", "1", "0", "Écumeur");
INSERT INTO `state` VALUES("9", "2020-03-29 14:03:22", "bailling", "state_8", "0", "Bailling - OK", "1", "0", "Bailling");
INSERT INTO `state` VALUES("10", "2020-03-30 13:14:22", "osmolateur", "state_2", "0", "Osmolateur - niveau eau OK", "1", "0", "Osmolateur");
INSERT INTO `state` VALUES("11", "2020-03-28 19:49:05", "reacteur", "state_99", "0", "Réacteur - Désactivé", "1", "0", "Réacteur");


-- --------------------------------------------------------


--
-- Table status
--

DROP TABLE IF EXISTS `status`;

CREATE TABLE IF NOT EXISTS `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` tinyint(1) DEFAULT NULL COMMENT 'Activé/Désactivé',
  `label` varchar(255) DEFAULT NULL,
  `groupe` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `status` VALUES("1", "osmolateur", "1", "Osmolateur", "1");
INSERT INTO `status` VALUES("2", "ecumeur", "1", "Écumeur", "1");
INSERT INTO `status` VALUES("3", "bailling", "1", "Bailling", "1");
INSERT INTO `status` VALUES("4", "reacteur", "1", "Réacteur", "1");
INSERT INTO `status` VALUES("5", "temperature", "1", "Température", "1");
INSERT INTO `status` VALUES("6", "reacteur_ventilateur", "1", "Activer ventilateur réacteur", "2");
INSERT INTO `status` VALUES("7", "reacteur_eclairage", "1", "Activer éclairage réacteur", "2");
INSERT INTO `status` VALUES("8", "cron_controle", "1", "Activer cron check dernière activité", "2");
INSERT INTO `status` VALUES("9", "cron_rappel", "1", "Activer mail rappel ajout à faire", "2");
INSERT INTO `status` VALUES("10", "mail", "0", "Activer envoie email", "2");
INSERT INTO `status` VALUES("11", "refroidissement", "0", "Activer ventilateur boîtier 24/24h", "2");
INSERT INTO `status` VALUES("12", "on_off_osmolateur", "0", "On/Off osmolateur", "3");
INSERT INTO `status` VALUES("13", "on_off_ecumeur", "0", "On/Off écumeur", "3");
INSERT INTO `status` VALUES("14", "log_in_files", "0", "Activer log in files", "4");
INSERT INTO `status` VALUES("15", "force_turn_on_eclairage", "1", "forcer allumage éclairege reacteur", "5");


-- --------------------------------------------------------


